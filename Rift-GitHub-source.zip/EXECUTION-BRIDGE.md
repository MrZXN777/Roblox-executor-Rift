# Rift execution bridge

As of v0.6.4, the connection dialog and related controls are no longer exposed in Rift's UI. The protocol below is retained for development and tests, not as an available end-user workflow.

Rift can deliver Lua or Luau text to an **opt-in runtime adapter** on the same computer. The adapter is responsible for executing it in a game or tool that supports scripting. Rift does not attach to, modify, or inject into a game process, and an adapter's account label is not a login or proof of identity.

The internal bridge API starts a server bound to `127.0.0.1` on a random port and issues a pairing token. Keep the token private. It exists only in memory and changes after a bridge restart.

Automated tests use a local demo adapter through this bridge. It runs Luau in a separate worker and does not represent an installed game client.

## Historical Real adapter

The adapter generator remains in source for compatibility tests, but Rift v0.6.4 has no UI to copy, connect, or execute through it. The bridge can record an adapter's account label and optional client details (kind, place ID, universe ID, server job ID). Process detection alone never marks a runtime connected.

The copied code contains the bridge's bearer token. Keep it private and do not paste it into a shared place. Rift and Real must run on the same computer. Rift is a frontend for Real in this mode and does not inject into Roblox. An execution result confirms a script compiled and completed or started; it does not guarantee a persistent script will keep running without later errors. Use Real's console for later errors. Real's own runtime and client support determine game compatibility.

The adapter uses JSON over HTTP. Every request includes `Authorization: Bearer <token>`. After registration, include `X-Rift-Session: <sessionId>` on subsequent requests.

1. `POST /v1/session` with `{"name":"My adapter","account":"PlayerOne"}`. The response contains `sessionId`. Only one adapter session is active; a new registration replaces the previous one.
2. Poll `GET /v1/jobs`. The response is `{"job":null}` or a job with `id`, `name`, `code`, and `account`.
3. Execute the job through the target's supported scripting API. Then `POST /v1/result` with `{"id":"<job id>","ok":true,"output":["Hello"]}`. Send `ok:false` and an error line when execution fails.

The internal bridge rejects a mismatched account label, limits the queue to ten requests, and expires unanswered jobs after 30 seconds. The editor's **Run locally** button uses Rift's isolated Luau worker and does not use this bridge.

The HTTP server rejects browser `Origin` requests and requests without the pairing token. The bridge shuts down when Rift closes. An adapter should poll while connected and must not expose the token to the game or other processes.

`adapter/runtime-adapter.mjs` implements registration, polling, and result delivery. Supply its `execute(code, context)` callback using your target's documented scripting API. The connection is declared offline after 15 seconds without a poll or result request.
