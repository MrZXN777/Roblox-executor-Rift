// Use this client from an adapter for a game or tool with a supported scripting API.
export async function connectRuntime({address,token,name,account,client,execute,signal,pollMs=500}) {
 if(!/^http:\/\/127\.0\.0\.1:\d+$/.test(address)||typeof token!=='string'||typeof execute!=='function')throw Error('Invalid bridge connection.');
 const headers={Authorization:`Bearer ${token}`};
 async function request(route,method='GET',body,sessionId){
  const response=await fetch(address+route,{method,headers:{...headers,...(sessionId?{'X-Rift-Session':sessionId}:{}),...(body?{'Content-Type':'application/json'}:{})},body:body&&JSON.stringify(body),signal});
  const data=await response.json();if(!response.ok)throw Error(data.error||`Bridge request failed (${response.status}).`);return data;
 }
 const {sessionId}=await request('/v1/session','POST',{name,account,client});
 try{while(!signal?.aborted){
  const {job}=await request('/v1/jobs','GET',undefined,sessionId);
  if(job){let ok=true,output=[];try{const result=await execute(job.code,{name:job.name,account:job.account,signal});if(Array.isArray(result))output=result.map(String);else if(result!==undefined)output=[String(result)]}catch(error){ok=false;output=[error.message||String(error)]}await request('/v1/result','POST',{id:job.id,ok,output:output.slice(0,1000).map(line=>line.slice(0,10000))},sessionId)}
  await new Promise(resolve=>setTimeout(resolve,pollMs));
 }}catch(error){if(!signal?.aborted)throw error}
}
