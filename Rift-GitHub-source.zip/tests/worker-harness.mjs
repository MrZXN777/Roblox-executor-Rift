import {parentPort,workerData} from 'node:worker_threads';
globalThis.self=globalThis;
globalThis.postMessage=data=>parentPort.postMessage(data);
await import('../src/runtime.worker.js');
self.onmessage({data:workerData});
