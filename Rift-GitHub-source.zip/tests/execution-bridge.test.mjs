import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const {createExecutionBridge}=createRequire(import.meta.url)('../electron/execution-bridge.cjs');
import {connectRuntime} from '../adapter/runtime-adapter.mjs';
import {Worker} from 'node:worker_threads';

test('paired runtime receives a script and returns output',async()=>{
 const bridge=createExecutionBridge({jobTimeoutMs:2000});
 try{
  const {address,token}=await bridge.start();
  const request=(route,method='GET',body,sessionId)=>fetch(address+route,{method,headers:{Authorization:`Bearer ${token}`,...(sessionId?{'X-Rift-Session':sessionId}:{}),...(body?{'Content-Type':'application/json'}:{})},body:body&&JSON.stringify(body)});
  assert.equal((await fetch(address+'/v1/jobs')).status,401);
  const registration=await request('/v1/session','POST',{name:'Test adapter',account:'PlayerOne'});
  const {sessionId}=await registration.json();
  assert.equal(bridge.status().session.account,'PlayerOne');
  assert.throws(()=>bridge.execute({name:'x.lua',code:'print(1)',account:'OtherPlayer'}),/account/);
  const completed=bridge.execute({name:'x.lua',code:'print(1)',account:'PlayerOne'});
  const job=await (await request('/v1/jobs','GET',undefined,sessionId)).json();
  assert.equal(job.job.code,'print(1)');
  assert.equal((await request('/v1/result','POST',{id:job.job.id,ok:true,output:['1']},sessionId)).status,200);
  assert.deepEqual(await completed,{ok:true,output:['1'],account:'PlayerOne'});
  const blank=bridge.execute({name:'blank.lua',code:'print()',account:'PlayerOne'});
  const blankJob=await (await request('/v1/jobs','GET',undefined,sessionId)).json();
  assert.equal((await request('/v1/result','POST',{id:blankJob.job.id,ok:true,output:['']},sessionId)).status,200);
  assert.deepEqual((await blank).output,['']);
  assert.equal((await request('/v1/jobs','GET',undefined,sessionId)).status,200);
 }finally{await bridge.stop()}
});

test('bridge rejects browser origins and expires unanswered work',async()=>{
 const bridge=createExecutionBridge({jobTimeoutMs:30});
 try{
  const {address,token}=await bridge.start();
  assert.equal((await fetch(address+'/v1/session',{method:'POST',headers:{Authorization:`Bearer ${token}`,Origin:'https://example.test'},body:JSON.stringify({name:'x',account:'y'})})).status,403);
  const response=await fetch(address+'/v1/session',{method:'POST',headers:{Authorization:`Bearer ${token}`},body:JSON.stringify({name:'Adapter',account:'PlayerOne'})});
  assert.equal(response.status,200);
  await assert.rejects(bridge.execute({name:'x.lua',code:'print(1)',account:'PlayerOne'}),/time/);
  assert.equal(bridge.status().pending,0);
 }finally{await bridge.stop()}
});

test('bridge reports paired client identity and validates metadata',async()=>{
 const bridge=createExecutionBridge();
 try{
  const {address,token}=await bridge.start();
  const headers={Authorization:`Bearer ${token}`,'Content-Type':'application/json'};
  const register=body=>fetch(address+'/v1/session',{method:'POST',headers,body:JSON.stringify(body)});
  assert.equal((await register({name:'Real Roblox Player',account:'PlayerOne',client:{kind:'Roblox Player',placeId:-1}})).status,400);
  assert.equal(bridge.status().session,null);
  assert.equal((await register({name:'Real Roblox Player',account:'PlayerOne',client:{kind:'Roblox Player',placeId:1234,universeId:5678,jobId:'session-id'}})).status,200);
  assert.deepEqual(bridge.status().session.client,{kind:'Roblox Player',placeId:1234,universeId:5678,jobId:'session-id'});
 }finally{await bridge.stop()}
});

test('adapter callback completes a script through the bridge',async()=>{
 const bridge=createExecutionBridge({jobTimeoutMs:2000}),controller=new AbortController();
 try{
  const {address,token}=await bridge.start();
  const adapter=connectRuntime({address,token,name:'Example game',account:'PlayerOne',execute:async code=>[`received ${code}`],pollMs:10,signal:controller.signal});
  for(let i=0;i<100&&!bridge.status().connected;i++)await new Promise(resolve=>setTimeout(resolve,10));
  assert.equal(bridge.status().connected,true);
  assert.deepEqual(await bridge.execute({name:'example.lua',code:'print(2)',account:'PlayerOne'}),{ok:true,output:['received print(2)'],account:'PlayerOne'});
  controller.abort();await adapter;
 }finally{controller.abort();await bridge.stop()}
});

test('demo worker executes Luau and captures output',async()=>{
 const worker=new Worker(new URL('../electron/demo-worker.mjs',import.meta.url),{workerData:{code:'print(2 + 3)',name:'demo.lua'}});
 try{const result=await new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject)});assert.deepEqual(result,{ok:true,output:['5']})}
 finally{await worker.terminate()}
});

test('demo worker reports returned values',async()=>{
 const worker=new Worker(new URL('../electron/demo-worker.mjs',import.meta.url),{workerData:{code:'return 42, "ready"',name:'demo.lua'}});
 try{const result=await new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject)});assert.deepEqual(result,{ok:true,output:['Return: 42\tready']})}
 finally{await worker.terminate()}
});
