import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createRealAdapter} from '../src/real-adapter.js';

const require = createRequire(import.meta.url);
const {createExecutionBridge} = require('../electron/execution-bridge.cjs');

test('Real adapter contains the paired endpoint and live execution APIs', () => {
 const address = 'http://127.0.0.1:12345';
 const token = 'a'.repeat(64);
 const source = createRealAdapter(address, token);
 assert.match(source, /loadstring\(job\.code, job\.name\)/);
 assert.match(source, /request\(\{/);
 assert.match(source, /placeId = game\.PlaceId/);
 assert.ok(source.includes(address));
 assert.ok(source.includes(token));
 assert.throws(() => createRealAdapter('https://example.com', token), /Invalid Rift bridge/);
});

test('execution bridge delivers a script to a paired runtime and returns its result', async () => {
 const bridge = createExecutionBridge();
 const {address, token} = await bridge.start();
 const request = async (route, method, body, sessionId) => {
  const response = await fetch(address + route, {
   method,
   headers: {
    Authorization: `Bearer ${token}`,
    ...(sessionId ? {'X-Rift-Session': sessionId} : {}),
    ...(body ? {'Content-Type': 'application/json'} : {}),
   },
   body: body ? JSON.stringify(body) : undefined,
  });
  assert.equal(response.status, 200);
  return response.json();
 };
 try {
  const {sessionId} = await request('/v1/session', 'POST', {name: 'Real Roblox Player', account: 'TestPlayer'});
  const result = bridge.execute({name: 'smoke.luau', code: 'return 42', account: 'TestPlayer'});
  const {job} = await request('/v1/jobs', 'GET', undefined, sessionId);
  assert.equal(job.code, 'return 42');
  await request('/v1/result', 'POST', {id: job.id, ok: true, output: ['42']}, sessionId);
  assert.deepEqual(await result, {ok: true, output: ['42'], account: 'TestPlayer'});
 } finally {
  await bridge.stop();
 }
});
