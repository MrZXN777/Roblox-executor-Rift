export function installMotion({editor,getSettings}){
 const reduce=()=>matchMedia('(prefers-reduced-motion: reduce)').matches||!getSettings().animations;
 const ambient=document.createElement('div');ambient.className='ambient';ambient.setAttribute('aria-hidden','true');document.body.prepend(ambient);
 const ink=document.createElement('div');ink.className='edit-ink';ink.setAttribute('aria-hidden','true');document.querySelector('.editor-content').append(ink);
 let fade;
 editor.onDidChangeModelContent(event=>{
  if(reduce()||!getSettings().typingMotion)return;
  const position=editor.getPosition();if(!position)return;
  const box=editor.getScrolledVisiblePosition(position);if(!box)return;
  const removed=event.changes.some(c=>c.rangeLength>c.text.length);
  ink.style.transform=`translate3d(${box.left-2}px,${box.top+2}px,0)`;
  ink.style.height=`${Math.max(12,box.height-4)}px`;
  ink.classList.toggle('deleting',removed);ink.classList.add('visible');clearTimeout(fade);
  fade=setTimeout(()=>ink.classList.remove('visible'),110);
 });
 const nav=document.querySelector('.topnav');const indicator=document.createElement('i');indicator.className='nav-indicator';indicator.setAttribute('aria-hidden','true');nav.append(indicator);
 let frame;const move=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const active=nav.querySelector('.active');if(active){indicator.style.width=`${Math.max(12,active.offsetWidth-8)}px`;indicator.style.transform=`translateX(${active.offsetLeft+4}px)`}})};
 const observer=new ResizeObserver(move);nav.querySelectorAll('button').forEach(b=>observer.observe(b));new MutationObserver(move).observe(nav,{subtree:true,attributes:true,attributeFilter:['class']});move();
 const scrolls=new WeakMap();
 document.addEventListener('wheel',event=>{
  if(reduce()||!getSettings().smoothScroll||event.ctrlKey||event.metaKey||Math.abs(event.deltaY)<30||event.target.closest('.monaco-editor'))return;
  const target=event.target.closest('.console-body,.welcome,.dialog,.main');if(!target||target.scrollHeight<=target.clientHeight)return;
  if(Math.abs(event.deltaX)>Math.abs(event.deltaY))return;
  const max=target.scrollHeight-target.clientHeight;
  let s=scrolls.get(target);if(!s){s={goal:target.scrollTop,frame:0,last:0};scrolls.set(target,s)}
  if(!s.frame)s.goal=target.scrollTop;
  s.goal=Math.min(max,Math.max(0,s.goal+event.deltaY*(event.deltaMode===1?18:1)));
  if((target.scrollTop<=0&&event.deltaY<0)||(target.scrollTop>=max-1&&event.deltaY>0))return;
  event.preventDefault();if(s.frame)return;
  s.last=performance.now();const step=now=>{const elapsed=Math.min(40,now-s.last);s.last=now;const delta=s.goal-target.scrollTop;if(Math.abs(delta)<.8||reduce()){target.scrollTop=s.goal;s.frame=0;return}target.scrollTop+=delta*(1-Math.exp(-elapsed/70));s.frame=requestAnimationFrame(step)};s.frame=requestAnimationFrame(step);
 },{passive:false});
 document.addEventListener('pointerdown',event=>{const target=event.target.closest('.main,.welcome,.dialog,.console-body');const s=target&&scrolls.get(target);if(s){cancelAnimationFrame(s.frame);s.frame=0}});
 document.addEventListener('click',event=>{const button=event.target.closest('button');if(!button||button.disabled||reduce()||button.classList.contains('switch'))return;button.animate([{opacity:.78},{opacity:1}],{duration:170,easing:'ease-out'})});
}
