// Shared menu behavior: all actions come from the workspace, never from rendered text.
export function installContextMenus({itemsFor,onError}){
 let menu,previous;
 function close(restore=false){menu?.remove();menu=null;if(restore&&previous?.isConnected)previous.focus()}
 function show(target,x,y){const items=itemsFor(target);if(!items?.length)return false;close();previous=document.activeElement;menu=document.createElement('div');menu.className='context-menu';menu.setAttribute('role','menu');menu.setAttribute('aria-label','Workspace actions');
  for(const item of items){if(!item){const line=document.createElement('div');line.className='menu-divider';line.setAttribute('role','separator');menu.append(line);continue}const button=document.createElement('button');button.type='button';button.setAttribute('role','menuitem');button.disabled=!!item.disabled;button.className=item.danger?'danger':'';const label=document.createElement('span');label.textContent=item.label;button.append(label);if(item.hint){const hint=document.createElement('small');hint.textContent=item.hint;button.append(hint)}button.onclick=async()=>{close(true);try{await item.run()}catch(error){onError(error.message)}};menu.append(button)}
  document.body.append(menu);const box=menu.getBoundingClientRect();menu.style.left=Math.max(6,Math.min(x,innerWidth-box.width-6))+'px';menu.style.top=Math.max(6,Math.min(y,innerHeight-box.height-6))+'px';menu.querySelector('button:not(:disabled)')?.focus();return true;
 }
 document.addEventListener('contextmenu',event=>{if(event.target.closest('.monaco-editor,input,textarea,[contenteditable],.dialog'))return;if(show(event.target,event.clientX,event.clientY))event.preventDefault()});
 document.addEventListener('pointerdown',event=>{if(menu&&!menu.contains(event.target))close()});
 document.addEventListener('keydown',event=>{if(menu){const buttons=[...menu.querySelectorAll('button:not(:disabled)')],index=buttons.indexOf(document.activeElement);if(['ArrowDown','ArrowUp','Home','End','Escape','Tab'].includes(event.key)){event.preventDefault();event.stopImmediatePropagation();if(event.key==='Escape'||event.key==='Tab')close(true);else buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowUp'?-1:1)+buttons.length)%buttons.length]?.focus()}}else if(event.key==='ContextMenu'||event.shiftKey&&event.key==='F10'){const target=document.activeElement,box=target.getBoundingClientRect();if(show(target,box.left+12,box.bottom))event.preventDefault()}},true);
 window.addEventListener('blur',()=>close());window.addEventListener('resize',()=>close());document.addEventListener('scroll',event=>{if(menu&&!menu.contains(event.target))close()},true);
}

export function installSidebarGlide(getSettings){
 const sidebar=document.querySelector('.sidebar');let host,pill,hover;
 const position=()=>{const current=sidebar.querySelector('.side-items');if(!current)return;if(host!==current){host=current;pill=document.createElement('i');pill.className='sidebar-glide';pill.setAttribute('aria-hidden','true');host.prepend(pill);hover=null;host.classList.add('glide-host')}
 const item=hover?.isConnected?hover:host.querySelector('.side-item.selected,.tree-file.active');pill.style.opacity=item?'1':'0';if(item){pill.style.transform=`translate3d(${item.offsetLeft}px,${item.offsetTop}px,0)`;pill.style.width=item.offsetWidth+'px';pill.style.height=item.offsetHeight+'px'}pill.style.transitionDuration=getSettings().animations?'':'0ms'};
 sidebar.addEventListener('pointerover',e=>{const item=e.target.closest('.side-items .side-item,.side-items .tree-file');if(item){hover=item;position()}});sidebar.addEventListener('pointerleave',()=>{hover=null;position()});sidebar.addEventListener('focusin',e=>{const item=e.target.closest('.side-items .side-item,.side-items .tree-file');if(item){hover=item;position()}});sidebar.addEventListener('focusout',()=>{hover=null;position()});
 new MutationObserver(position).observe(sidebar,{childList:true});new ResizeObserver(position).observe(sidebar);position();
}
