export function createRealAdapter(address, token) {
 if(!/^http:\/\/127\.0\.0\.1:\d+$/.test(address)||!/^[a-f0-9]{64}$/.test(token))throw Error('Invalid Rift bridge connection.');
 return `local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local address = ${JSON.stringify(address)}
local token = ${JSON.stringify(token)}
local account = Players.LocalPlayer.Name

local previous = getgenv().__riftBridge
if previous then previous.stop() end

local bridge = {running = true}
function bridge.stop()
    bridge.running = false
    if getgenv().__riftBridge == bridge then
        getgenv().__riftBridge = nil
    end
end
getgenv().__riftBridge = bridge

local function call(route, method, body, sessionId)
    local headers = {Authorization = "Bearer " .. token}
    if sessionId then headers["X-Rift-Session"] = sessionId end
    if body then headers["Content-Type"] = "application/json" end
    local response = request({
        Url = address .. route,
        Method = method,
        Headers = headers,
        Body = body and HttpService:JSONEncode(body) or nil,
    })
    if type(response) ~= "table" then error(tostring(response)) end
    local data = HttpService:JSONDecode(response.Body)
    if not response.Success then error(data.error or ("HTTP " .. response.StatusCode)) end
    return data
end

local function runJob(job)
    local chunk, compileError = loadstring(job.code, job.name)
    if not chunk then return false, {tostring(compileError)} end
    local finished, succeeded, result = false, false, nil
    task.spawn(function()
        succeeded, result = pcall(chunk)
        finished = true
    end)
    local deadline = os.clock() + 0.2
    while not finished and os.clock() < deadline do task.wait() end
    if not finished then return true, {"Started in live Roblox Player."} end
    if not succeeded then return false, {tostring(result):sub(1, 10000)} end
    return true, {result ~= nil and tostring(result):sub(1, 10000) or "Completed in live Roblox Player."}
end

task.spawn(function()
    local ok, failure = pcall(function()
        local session = call("/v1/session", "POST", {name = "Real Roblox Player", account = account, client = {kind = "Roblox Player", placeId = game.PlaceId, universeId = game.GameId, jobId = game.JobId}}).sessionId
        print("Rift connected to " .. account)
        while bridge.running do
            local response = call("/v1/jobs", "GET", nil, session)
            if response.job and bridge.running then
                local succeeded, output = runJob(response.job)
                call("/v1/result", "POST", {id = response.job.id, ok = succeeded, output = output}, session)
            end
            task.wait(0.5)
        end
    end)
    if not ok and bridge.running then warn("Rift connection stopped: " .. tostring(failure)) end
    bridge.stop()
end)
`;
}
