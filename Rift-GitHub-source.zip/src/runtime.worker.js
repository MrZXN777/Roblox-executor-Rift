import {executeLuau} from '../shared/luau-engine.mjs';

self.onmessage=async({data})=>{
 try{
  const {LuauState}=await import('luau-web');
  const result=await executeLuau({LuauState,code:data.code,name:data.name,check:data.check,onReady:()=>postMessage({type:'ready'}),onOutput:(level,text)=>postMessage({type:'output',level,text})});
  if(result.checked)postMessage({type:'checked'});
  else{
   if(result.values.length)postMessage({type:'output',level:'info',text:'Return: '+result.values.join('\t')});
   postMessage({type:'done'});
  }
 }catch(error){postMessage({type:'error',text:error.message||String(error)})}
};
