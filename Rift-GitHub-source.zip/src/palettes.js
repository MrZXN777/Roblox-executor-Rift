export const palettes={
 graphite:{name:'Dark',colors:['#111413','#242a27','#727c75','#e6ece8'],accent:'#60dba2'},
 midnight:{name:'Blue',colors:['#0e1620','#1c3448','#80bde6','#d2e7f5'],accent:'#89c5ed'},
 purple:{name:'Purple',colors:['#14101c','#33273f','#ba9be1','#ece2fa'],accent:'#c1a5e8'},
 red:{name:'Red',colors:['#1a1012','#45262b','#cf7c87','#f9dfe4'],accent:'#ea9aa4'},
 orange:{name:'Orange',colors:['#1a140f','#423327','#d1a17d','#f7e5d7'],accent:'#e1ad81'},
 pink:{name:'Pink',colors:['#1b1218','#402b38','#d69eba','#f6e2ed'],accent:'#ecb1d1'},
 sakura:{name:'Sakura',colors:['#fcf7fa','#efdee7','#c37b9e','#32202a'],accent:'#ae507e',light:true},
 green:{name:'Green',colors:['#0c1812','#1a3929','#82c799','#e0f1e5'],accent:'#8ddeab'},
 teal:{name:'Teal',colors:['#0c1918','#183b36','#73c7b9','#d5f1eb'],accent:'#8fddce'},
 cyan:{name:'Cyan',colors:['#0c171a','#163941','#76cadb','#d7f4fa'],accent:'#80d4e5'},
 yellow:{name:'Yellow',colors:['#19170e','#413c22','#c4b365','#f3edce'],accent:'#e2cf80'},
 indigo:{name:'Indigo',colors:['#111221','#292c51','#a1a8e9','#e3e5fa'],accent:'#a6aef8'},
 light:{name:'Light',colors:['#f6f7f6','#e2e7e4','#b3beb7','#27362d'],accent:'#3b976c',light:true}
};
export function resolvePalette(settings){
 if(settings.theme==='custom')return {name:'Custom',colors:[settings.customBg||'#101412',settings.customPanel||'#1b2420','#8aa297','#e4efe8'],accent:settings.customAccent||'#9fd3b8'};
 return palettes[settings.theme]||palettes.graphite;
}
