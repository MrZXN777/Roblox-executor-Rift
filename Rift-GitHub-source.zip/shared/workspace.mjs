export function validate(data){
 if(!data||data.version!==1||!Array.isArray(data.scripts)||!Array.isArray(data.profiles)||!data.settings)throw Error('Invalid workspace format.');
 if(data.scripts.length>500||data.profiles.length>100)throw Error('Workspace limit exceeded.');
 const ids=new Set();
 for(const s of data.scripts){if(typeof s.id!=='string'||ids.has(s.id)||typeof s.name!=='string'||!s.name.trim()||s.name.length>100||typeof s.code!=='string'||s.code.length>1_000_000)throw Error('Invalid script.');ids.add(s.id)}
 for(const p of data.profiles){if(typeof p.id!=='string'||typeof p.username!=='string'||!/^\w{3,20}$/.test(p.username)||typeof p.placeId!=='string'||(p.placeId&&!/^\d{1,20}$/.test(p.placeId)))throw Error('Invalid profile.');if(p.group!==undefined&&(typeof p.group!=='string'||p.group.length>40))throw Error('Invalid profile group.');if(p.pinned!==undefined&&typeof p.pinned!=='boolean')throw Error('Invalid profile pin.');}
 if(!['graphite','midnight','purple','red','orange','pink','sakura','green','teal','cyan','yellow','indigo','light','custom'].includes(data.settings.theme)||!Number.isFinite(data.settings.fontSize)||data.settings.fontSize<11||data.settings.fontSize>24||![3,5,10,30].includes(data.settings.timeout))throw Error('Invalid settings.');
 for(const k of ['customBg','customPanel','customAccent'])if(data.settings[k]!==undefined&&!/^#[0-9a-f]{6}$/i.test(data.settings[k]))throw Error('Invalid theme color.');
 if(!Array.isArray(data.history)||data.history.length>100)throw Error('Invalid history.');
 const ranges={lineHeight:[16,34],letterSpacing:[0,3],animationSpeed:[.5,2],terminalOpacity:[30,100],maxLines:[100,1000],sidebarWidth:[170,340],consoleHeight:[85,320]};
 for(const [key,[min,max]] of Object.entries(ranges)){const v=data.settings[key];if(v!==undefined&&(!Number.isFinite(v)||v<min||v>max))throw Error('Invalid setting: '+key)}
 if(data.settings.savedLayout!==undefined){const l=data.settings.savedLayout;if(!l||Object.keys(l).some(k=>!['sidebarWidth','consoleHeight','sidebarRight','navPosition'].includes(k))||!Number.isFinite(l.sidebarWidth)||l.sidebarWidth<170||l.sidebarWidth>340||!Number.isFinite(l.consoleHeight)||l.consoleHeight<85||l.consoleHeight>320||typeof l.sidebarRight!=='boolean'||!['Top','Bottom'].includes(l.navPosition))throw Error('Invalid saved layout.');}
 for(const key of ['keyRun','keyClients']){const v=data.settings[key];if(v!==undefined&&(typeof v!=='string'||!/^([A-Za-z0-9]|F([1-9]|1[0-2]))$/.test(v)))throw Error('Invalid key binding.')}
 if(data.settings.defaultCode!==undefined&&(typeof data.settings.defaultCode!=='string'||data.settings.defaultCode.length>100000))throw Error('Invalid default code.');
 if(data.openIds!==undefined&&(!Array.isArray(data.openIds)||data.openIds.some(id=>typeof id!=='string')))throw Error('Invalid open tabs.');
 const booleans=['minimap','wordWrap','animations','animatedLogo','ambient','sidebarRight','alwaysOnTop','resizable','ligatures','statusBar','hideTerminal','autoConsole','confirmClose','restoreTabs','confirmClear','confirmDelete','smoothScroll','typingMotion','smoothCaret','dynamicTabs','fullPath','blockIndent','restoreScroll','pinTerminal','clearOnDisconnect','saveWindowSize','trayOnClose','capturePrivacy','musicFocus','musicVisualizer','hideExtensions','hideLocal','hideCloud','hideAuto','showNotifications'];
 for(const key of booleans)if(data.settings[key]!==undefined&&typeof data.settings[key]!=='boolean')throw Error('Invalid setting: '+key);
 const enums={animationStyle:['Smooth','Snappy','Minimal'],navPosition:['Top','Bottom'],fontFamily:['Consolas','Cascadia Code','Cascadia Mono','Courier New','monospace'],cursorStyle:['line','line-thin','block','underline'],renderWhitespace:['none','boundary','all'],autoIndent:['none','keep','brackets','advanced','full'],accountView:['Grid','List'],scriptView:['Grid','List'],buttonSound:['Off','Tap','Soft'],scriptSource:['All sources','My scripts','Bundled examples'],scriptSort:['Default','Name','Recently edited']};
 for(const [key,values] of Object.entries(enums))if(data.settings[key]!==undefined&&!values.includes(data.settings[key]))throw Error('Invalid setting: '+key);
 if(data.settings.musicVolume!==undefined&&(!Number.isFinite(data.settings.musicVolume)||data.settings.musicVolume<0||data.settings.musicVolume>100))throw Error('Invalid music volume.');
 if(data.settings.keyRun!==undefined&&data.settings.keyRun===data.settings.keyClients)throw Error('Duplicate shortcut.');
 const profileIds=new Set();for(const profile of data.profiles){if(profileIds.has(profile.id))throw Error('Duplicate profile.');profileIds.add(profile.id)}
 for(const h of data.history)if(!h||typeof h.scriptId!=='string'||typeof h.name!=='string'||!Number.isFinite(h.time)||typeof h.ok!=='boolean')throw Error('Invalid history entry.');
 if(data.savedThemes!==undefined){if(!Array.isArray(data.savedThemes)||data.savedThemes.length>30)throw Error('Invalid saved themes.');const ids=new Set();for(const t of data.savedThemes){if(!t||typeof t.id!=='string'||ids.has(t.id)||typeof t.name!=='string'||!t.name.trim()||t.name.length>50)throw Error('Invalid saved theme.');ids.add(t.id);validateAppearance(t.appearance)}}
 if(JSON.stringify(data).length>15_000_000)throw Error('Workspace is too large.');
 return data;
}

export function validateAppearance(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||!['graphite','midnight','purple','red','orange','pink','sakura','green','teal','cyan','yellow','indigo','light','custom'].includes(value.theme))throw Error('Invalid theme file.');
 for(const k of ['customBg','customPanel','customAccent'])if(value[k]!==undefined&&!/^#[0-9a-f]{6}$/i.test(value[k]))throw Error('Invalid theme color.');
 if(value.theme==='custom'&&['customBg','customPanel','customAccent'].some(k=>!value[k]))throw Error('Custom themes need background, surface, and accent colors.');
 if(value.animationSpeed!==undefined&&(!Number.isFinite(value.animationSpeed)||value.animationSpeed<.5||value.animationSpeed>2))throw Error('Invalid animation speed.');
 for(const k of ['animations','ambient','smoothScroll','typingMotion','animatedLogo','sidebarRight'])if(value[k]!==undefined&&typeof value[k]!=='boolean')throw Error('Invalid theme option.');
 if(value.animationStyle!==undefined&&!['Smooth','Snappy','Minimal'].includes(value.animationStyle))throw Error('Invalid animation style.');
 if(value.navPosition!==undefined&&!['Top','Bottom'].includes(value.navPosition))throw Error('Invalid navigation position.');
 const allowed=['theme','customBg','customPanel','customAccent','animations','animationSpeed','animationStyle','ambient','smoothScroll','typingMotion','animatedLogo','sidebarRight','navPosition'];
 return Object.fromEntries(allowed.filter(k=>Object.hasOwn(value,k)).map(k=>[k,value[k]]));
}
