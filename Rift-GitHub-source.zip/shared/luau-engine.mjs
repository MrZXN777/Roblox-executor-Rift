export async function executeLuau({LuauState,code,name='script.luau',check=false,onReady=()=>{},onOutput=()=>{},maxOutput=500}){
 if(typeof code!=='string'||typeof name!=='string')throw Error('Invalid Luau script.');
 if(!LuauState?.createAsync)throw Error('Luau runtime is unavailable.');
 let state,lines=0;
 const output=(level,values)=>{
  if(++lines<=maxOutput)onOutput(level,values.map(value=>String(value)).join('\t').slice(0,10000));
  else if(lines===maxOutput+1)onOutput('warn',`Output limit reached (${maxOutput} lines). Further output suppressed.`);
 };
 try{
  state=await LuauState.createAsync({print:(...values)=>output('info',values),warn:(...values)=>output('warn',values)});
  onReady();
  const fn=state.loadstring(code,name,true);
  if(check)return {checked:true,values:[]};
  const result=await fn();
  return {checked:false,values:Array.isArray(result)?result.map(value=>String(value).slice(0,10000)):[]};
 }finally{state?.destroy()}
}
