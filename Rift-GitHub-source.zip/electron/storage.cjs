const fs=require('node:fs/promises');
const path=require('node:path');
const {validate}=require('../shared/workspace.mjs');
function createStore(file){let queue=Promise.resolve();return {
 async load(){try{return validate(JSON.parse(await fs.readFile(file,'utf8')))}catch(e){if(e.code==='ENOENT')return null;throw Error('Workspace could not be read; original file was preserved. '+e.message)}},
 save(data){validate(data);const body=JSON.stringify(data,null,2);const operation=queue.catch(()=>{}).then(async()=>{await fs.mkdir(path.dirname(file),{recursive:true});await fs.writeFile(file+'.tmp',body,'utf8');await fs.rename(file+'.tmp',file);return true});queue=operation;return operation},
 flush(){return queue}
}}
module.exports={validate,createStore};
