const fs=require('node:fs/promises');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const {validate}=require('../shared/workspace.mjs');

function gistId(input){
 if(typeof input!=='string'||input.length>250)throw Error('Enter a public GitHub Gist URL or ID.');
 const value=input.trim();if(/^[a-f0-9]{5,64}$/i.test(value))return value;
 let url;try{url=new URL(value)}catch{throw Error('Enter a public GitHub Gist URL or ID.')}
 const parts=url.pathname.split('/').filter(Boolean);
 if(url.protocol!=='https:'||url.hostname!=='gist.github.com'||url.port||url.username||url.password||parts.length!==2||!/^[-\w]+$/.test(parts[0])||!/^[a-f0-9]{5,64}$/i.test(parts[1]))throw Error('Use an HTTPS URL from gist.github.com.');
 return parts[1];
}
async function importGist(input,fetcher=fetch){
 const id=gistId(input),response=await fetcher('https://api.github.com/gists/'+id,{headers:{Accept:'application/vnd.github+json','User-Agent':'Rift-Desktop'},redirect:'error',signal:AbortSignal.timeout(10000)});
 if(!response.ok)throw Error(response.status===404?'Gist not found or not publicly accessible.':response.status===403||response.status===429?'GitHub rate limit reached. Try again later.':'GitHub returned HTTP '+response.status+'.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>3_000_000)throw Error('Gist response exceeds the 3 MB import limit.');parts.push(Buffer.from(value))}}finally{await reader.cancel().catch(()=>{})}
 const gist=JSON.parse(Buffer.concat(parts).toString('utf8'));
 if(gist.public!==true||!gist.files||typeof gist.files!=='object')throw Error('Only public gists are supported.');
 const files=[];let skipped=0;
 for(const file of Object.values(gist.files)){if(!file||typeof file.filename!=='string'||!file.filename.trim()||file.filename.length>100||! /\.(lua|luau|txt|md)$/i.test(file.filename)||file.truncated||typeof file.content!=='string'||file.content.length>1_000_000||files.length>=100){skipped++;continue}files.push({name:file.filename,code:file.content})}
 if(!files.length)throw Error('No complete Lua, Luau, text, or Markdown files were found.');
 return {id,url:'https://gist.github.com/'+id,description:typeof gist.description==='string'?gist.description.slice(0,300):'',files,skipped};
}

function createSync(configFile){
 let queue=Promise.resolve();
 async function configuration(){try{const c=JSON.parse(await fs.readFile(configFile,'utf8'));if(typeof c.folder!=='string'||!path.isAbsolute(c.folder))throw Error('Invalid sync folder.');return c}catch(e){if(e.code==='ENOENT')return null;throw e}}
 async function root(){const c=await configuration();if(!c)throw Error('Choose a sync folder first.');return path.join(c.folder,'Rift-Sync')}
 function serial(fn){const operation=queue.catch(()=>{}).then(fn);queue=operation;return operation}
 return {
  async status(){const c=await configuration();return {configured:!!c,folder:c?.folder||''}},
  configure(folder){return serial(async()=>{if(typeof folder!=='string'||!path.isAbsolute(folder)||!(await fs.stat(folder)).isDirectory())throw Error('Choose an existing folder.');await fs.mkdir(path.dirname(configFile),{recursive:true});await fs.writeFile(configFile+'.tmp',JSON.stringify({folder}));await fs.rename(configFile+'.tmp',configFile);return {configured:true,folder}})},
  disconnect(){return serial(async()=>{await fs.unlink(configFile).catch(e=>{if(e.code!=='ENOENT')throw e});return {configured:false,folder:''}})},
  publish(workspace){validate(workspace);const snapshot=JSON.stringify(workspace);if(Buffer.byteLength(snapshot,'utf8')>15_000_000)throw Error('Snapshot exceeds 15 MB.');return serial(async()=>{const dir=await root();await fs.mkdir(dir,{recursive:true});const name=Date.now()+'-'+randomUUID()+'.json';const temporary=path.join(dir,name+'.tmp');await fs.writeFile(temporary,snapshot,{flag:'wx'});await fs.rename(temporary,path.join(dir,name));return {name,createdAt:Date.now()}})},
  async list(){const dir=await root();let names;try{names=await fs.readdir(dir,{withFileTypes:true})}catch(e){if(e.code==='ENOENT')return [];throw e}const matching=names.filter(f=>f.isFile()&&/^\d{13}-[a-f0-9-]{36}\.json$/.test(f.name)).sort((a,b)=>b.name.localeCompare(a.name)).slice(0,50);return Promise.all(matching.map(async f=>{const stat=await fs.stat(path.join(dir,f.name));return {name:f.name,createdAt:Number(f.name.slice(0,13)),bytes:stat.size}}))},
  async read(name){if(typeof name!=='string'||!/^\d{13}-[a-f0-9-]{36}\.json$/.test(name))throw Error('Invalid snapshot.');const file=path.join(await root(),name),stat=await fs.lstat(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>15_000_000)throw Error('Invalid or oversized snapshot.');return validate(JSON.parse(await fs.readFile(file,'utf8')))}
 };
}
module.exports={gistId,importGist,createSync};
