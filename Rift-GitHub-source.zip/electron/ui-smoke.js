(async()=>{
 const wait=async(predicate,label)=>{for(let i=0;i<100;i++){const value=predicate();if(value)return value;await new Promise(resolve=>setTimeout(resolve,50))}throw Error('Timed out: '+label+'; console: '+document.querySelector('.console-body')?.textContent.slice(-500))};
 const click=selector=>{const element=document.querySelector(selector);if(!element)throw Error('Missing '+selector);element.click()};
 const result={};
 for(const route of ['Scripts','Accounts','Settings','Home']){click(`[data-route="${route}"]`);result[route]=!!document.querySelector('.page h2');if(!result[route])throw Error(route+' did not render')}
 click('[data-route="Accounts"]');click('[data-action="profile"]');
 await wait(()=>document.querySelector('.dialog[open] input[name="username"]'),'profile dialog');
 document.querySelector('.dialog input[name="username"]').value='DemoPlayer';
 document.querySelector('.dialog input[name="placeId"]').value='12345';
 document.querySelector('.dialog form').requestSubmit();
 await wait(()=>document.querySelector('.profile-card h3')?.textContent.includes('DemoPlayer'),'profile save');
 result.profile=true;
 click('[data-route="Editor"]');await wait(()=>document.querySelector('.monaco-editor'),'editor');
 click('[data-action="run"]');await wait(()=>document.querySelector('.console-body')?.textContent.includes('Execution completed.'),'local execution');result.local=true;
 if(document.querySelector('[data-action="bridgePanel"], [data-action="executeConnected"], [data-bridge]'))throw Error('Removed connection controls are still visible');
 click('[data-action="clients"]');
 await wait(()=>document.querySelector('.client-drawer')?.textContent.includes('Running processes'),'clients drawer');
 if(document.querySelector('.client-drawer')?.textContent.includes('Paired runtime'))throw Error('Removed runtime section is still visible');
 result.connectionUiRemoved=true;
 result.output=document.querySelector('.console-body').textContent.slice(-500);
 return result;
})()
