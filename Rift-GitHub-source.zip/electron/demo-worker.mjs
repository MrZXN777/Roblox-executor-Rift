import {parentPort,workerData} from 'node:worker_threads';
import {LuauState} from 'luau-web';
import {executeLuau} from '../shared/luau-engine.mjs';

const output=[];
try{
 const result=await executeLuau({LuauState,code:workerData.code,name:workerData.name,maxOutput:1000,onOutput:(level,text)=>output.push(level==='warn'?'WARN '+text:text)});
 if(result.values.length)output.push('Return: '+result.values.join('\t'));
 parentPort.postMessage({ok:true,output});
}catch(error){parentPort.postMessage({ok:false,output:[...output,error.message||String(error)]})}
