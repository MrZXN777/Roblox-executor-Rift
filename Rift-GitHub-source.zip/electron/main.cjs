const {app,BrowserWindow,ipcMain,dialog,shell,Menu,Tray,nativeImage,clipboard}=require('electron');
const path=require('node:path');
const fs=require('node:fs/promises');
const {execFile}=require('node:child_process');
const {promisify}=require('node:util');
const {Worker}=require('node:worker_threads');
const {createStore,validate}=require('./storage.cjs');
const run=promisify(execFile);
const {createSync,importGist}=require('./integrations.cjs');
const {createExecutionBridge}=require('./execution-bridge.cjs');
let win,store,tray,closing=false,nativeOptions={},boundsTimer;
app.setName('Rift');
if(process.env.RIFT_DATA_DIR)app.setPath('userData',path.resolve(process.env.RIFT_DATA_DIR));
function handle(channel,fn){ipcMain.handle(channel,async(event,...args)=>{if(event.sender!==win.webContents||event.senderFrame!==win.webContents.mainFrame)throw Error('Untrusted caller');return fn(...args)})}
app.whenReady().then(async()=>{
 store=createStore(path.join(app.getPath('userData'),'workspace.json'));
 let dimensions={width:1000,height:550};try{const saved=await store.load();if(saved?.settings?.saveWindowSize){const b=JSON.parse(await fs.readFile(path.join(app.getPath('userData'),'window.json'),'utf8'));if(b.width>=800&&b.width<=4000&&b.height>=500&&b.height<=3000)dimensions={width:b.width,height:b.height}}}catch{}
 win=new BrowserWindow({...dimensions,minWidth:800,minHeight:500,frame:false,backgroundColor:'#0d0f0e',title:'Rift',icon:path.join(__dirname,'../dist/icon.png'),show:!process.env.RIFT_SMOKE_TEST,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});
 Menu.setApplicationMenu(null);
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-navigate',e=>e.preventDefault());
 win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 handle('clipboard:write',text=>{if(typeof text!=='string'||text.length>15_000_000)throw Error('Clipboard text is too large.');clipboard.writeText(text);return true});
 const sync=createSync(path.join(app.getPath('userData'),'sync-folder.json'));
 const executionBridge=createExecutionBridge();
 let demoAbort=null,demoTask=null;
 async function runDemoScript(code,name){const worker=new Worker(path.join(__dirname,'demo-worker.mjs'),{workerData:{code,name}});try{return await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{worker.terminate();reject(Error('Demo runtime stopped after 5 seconds.'))},5000);worker.once('message',result=>{clearTimeout(timer);result.ok?resolve(result.output):reject(Error(result.output.join('\n')))});worker.once('error',error=>{clearTimeout(timer);reject(error)});worker.once('exit',exit=>{if(exit!==0){clearTimeout(timer);reject(Error('Demo runtime exited unexpectedly.'))}})})}finally{await worker.terminate()}}
 async function stopDemo(){demoAbort?.abort();demoAbort=null;await demoTask?.catch(()=>{});demoTask=null}
 handle('bridge:start',()=>executionBridge.start());
 handle('bridge:status',()=>executionBridge.status());
 handle('bridge:stop',async()=>{await stopDemo();return executionBridge.stop()});
 handle('bridge:demo',async()=>{if(demoTask)return executionBridge.status();const connection=await executionBridge.start();const {connectRuntime}=await import('../adapter/runtime-adapter.mjs');demoAbort=new AbortController();demoTask=connectRuntime({address:connection.address,token:connection.token,name:'Rift demo game',account:'DemoPlayer',client:{kind:'Local demo'},execute:(code,{name})=>runDemoScript(code,name),signal:demoAbort.signal}).finally(()=>{demoTask=null;demoAbort=null});for(let i=0;i<100&&!executionBridge.status().connected;i++)await new Promise(resolve=>setTimeout(resolve,20));if(!executionBridge.status().connected)throw Error('Demo runtime could not connect.');return executionBridge.status()});
 handle('bridge:execute',request=>executionBridge.execute(request));
 handle('sync:status',()=>sync.status());
 handle('sync:choose',async()=>{const result=await dialog.showOpenDialog(win,{properties:['openDirectory']});return result.canceled?null:sync.configure(result.filePaths[0])});
 handle('sync:disconnect',()=>sync.disconnect());
 handle('sync:publish',data=>sync.publish(data));
 handle('sync:list',()=>sync.list());
 handle('sync:read',name=>sync.read(name));
 handle('gist:import',url=>importGist(url));
 handle('workspace:load',()=>store.load());handle('workspace:save',data=>store.save(data));
 handle('script:open',async()=>{const result=await dialog.showOpenDialog(win,{properties:['openFile'],filters:[{name:'Luau scripts',extensions:['lua','luau','txt','md']}]});if(result.canceled)return null;const file=result.filePaths[0];if((await fs.stat(file)).size>1_000_000)throw Error('Script exceeds 1 MB.');return {name:path.basename(file),code:await fs.readFile(file,'utf8')}});
 handle('script:export',async(name,code)=>{if(typeof code!=='string'||code.length>15_000_000||typeof name!=='string')throw Error('Invalid script');const result=await dialog.showSaveDialog(win,{defaultPath:path.basename(name),filters:[{name:'Workspace file',extensions:[['json','txt','md','lua','luau'].includes(path.extname(name).slice(1))?path.extname(name).slice(1):'luau']}]});if(result.canceled)return false;await fs.writeFile(result.filePath,code,'utf8');return true});
 handle('workspace:backup',async data=>{validate(data);const result=await dialog.showSaveDialog(win,{defaultPath:'rift-backup.json',filters:[{name:'Rift workspace',extensions:['json']}]});if(result.canceled)return false;await fs.writeFile(result.filePath,JSON.stringify(data,null,2));return true});
 handle('workspace:restore',async()=>{const result=await dialog.showOpenDialog(win,{properties:['openFile'],filters:[{name:'Rift workspace',extensions:['json']}]});if(result.canceled)return null;if((await fs.stat(result.filePaths[0])).size>15_000_000)throw Error('Backup exceeds 15 MB.');return validate(JSON.parse(await fs.readFile(result.filePaths[0],'utf8')))});
 handle('clients:list',async()=>{if(process.platform!=='win32')return [];const {stdout}=await run('powershell.exe',['-NoProfile','-NonInteractive','-Command',"@(Get-Process -Name RobloxPlayerBeta,RobloxStudioBeta -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,MainWindowTitle) | ConvertTo-Json -Compress"],{windowsHide:true,timeout:5000,maxBuffer:100000});const parsed=stdout.trim()?JSON.parse(stdout):[];return Array.isArray(parsed)?parsed:[parsed]});
 handle('roblox:launch',async id=>{if(typeof id!=='string'||!/^\d{1,20}$/.test(id))throw Error('Enter a numeric Roblox place ID.');await shell.openExternal('roblox://experiences/start?placeId='+id);return true});
 handle('dialog:confirm',async message=>{if(typeof message!=='string'||message.length>500)throw Error('Invalid dialog');return (await dialog.showMessageBox(win,{type:'question',message,buttons:['Cancel','Continue'],defaultId:0,cancelId:0})).response===1});
 handle('window:action',action=>{if(action==='minimize')win.minimize();else if(action==='maximize')win.isMaximized()?win.unmaximize():win.maximize();else if(action==='close')win.close()});
 handle('window:settings',settings=>{if(typeof settings?.alwaysOnTop==='boolean')win.setAlwaysOnTop(settings.alwaysOnTop);if(typeof settings?.resizable==='boolean')win.setResizable(settings.resizable);if(typeof settings?.capturePrivacy==='boolean')win.setContentProtection(settings.capturePrivacy);nativeOptions={saveWindowSize:!!settings.saveWindowSize,trayOnClose:!!settings.trayOnClose};if(nativeOptions.trayOnClose&&!tray){tray=new Tray(nativeImage.createFromPath(path.join(__dirname,'../dist/icon.png')));tray.setToolTip('Rift');tray.setContextMenu(Menu.buildFromTemplate([{label:'Open Rift',click:()=>{win.show();win.focus()}},{label:'Quit Rift',click:()=>{nativeOptions.trayOnClose=false;win.close()}}]));tray.on('double-click',()=>{win.show();win.focus()})}if(!nativeOptions.trayOnClose&&tray){tray.destroy();tray=null}return true});
 handle('folder:import',async()=>{const pick=await dialog.showOpenDialog(win,{properties:['openDirectory']});if(pick.canceled)return null;const root=pick.filePaths[0],files=[];async function walk(dir,depth=0){if(depth>3||files.length>=200)return;for(const entry of await fs.readdir(dir,{withFileTypes:true})){if(files.length>=200)break;const file=path.join(dir,entry.name);if(entry.isDirectory()&&!entry.name.startsWith('.')&&entry.name!=='node_modules')await walk(file,depth+1);else if(entry.isFile()&&/\.(lua|luau|txt|md)$/i.test(entry.name)&&(await fs.stat(file)).size<=1_000_000)files.push({name:entry.name,relativePath:path.relative(root,file),code:await fs.readFile(file,'utf8')})}}await walk(root);return {folder:path.basename(root),files}});
 handle('audio:open',async()=>{const pick=await dialog.showOpenDialog(win,{properties:['openFile'],filters:[{name:'Audio',extensions:['mp3','wav','ogg','m4a']}]});if(pick.canceled)return null;const file=pick.filePaths[0];if((await fs.stat(file)).size>30_000_000)throw Error('Choose an audio file smaller than 30 MB.');const type={'.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg','.m4a':'audio/mp4'}[path.extname(file).toLowerCase()];if(!type)throw Error('Unsupported audio format.');return {name:path.basename(file),url:'data:'+type+';base64,'+(await fs.readFile(file)).toString('base64')}});
 win.on('resize',()=>{if(!nativeOptions.saveWindowSize||win.isMaximized())return;clearTimeout(boundsTimer);boundsTimer=setTimeout(()=>fs.writeFile(path.join(app.getPath('userData'),'window.json'),JSON.stringify(win.getBounds())).catch(()=>{}),250)});
 win.on('close',event=>{if(!closing){event.preventDefault();if(nativeOptions.trayOnClose){win.hide();return}win.webContents.send('window:closing')}});
 ipcMain.on('window:close-ready',async event=>{if(event.sender!==win.webContents)return;await store.flush().catch(()=>{});await stopDemo();await executionBridge.stop();closing=true;win.close()});
 win.loadFile(path.join(__dirname,'../dist/index.html'));
 if(process.env.RIFT_SMOKE_TEST){win.webContents.on('did-finish-load',async()=>{setTimeout(async()=>{try{const state=await win.webContents.executeJavaScript("({title:document.title,editor:!!document.querySelector('.monaco-editor'),bridge:!!window.riftExecution,text:document.body.innerText})");if(process.env.RIFT_DEMO_SMOKE_TEST)state.demo=await win.webContents.executeJavaScript("(async()=>{const session=await window.riftExecution.demo();const result=await window.riftExecution.execute({name:'smoke.lua',code:'print(2 + 3)',account:'DemoPlayer'});return {session,result}})()");if(process.env.RIFT_UI_SMOKE_TEST)state.ui=await win.webContents.executeJavaScript(await fs.readFile(path.join(__dirname,'ui-smoke.js'),'utf8'));await fs.writeFile(path.join(app.getPath('userData'),'smoke.json'),JSON.stringify(state));}catch(error){await fs.writeFile(path.join(app.getPath('userData'),'smoke-error.txt'),String(error)).catch(()=>{})}finally{await stopDemo();await executionBridge.stop();closing=true;app.quit()}},3500)});}
});
app.on('window-all-closed',()=>app.quit());
