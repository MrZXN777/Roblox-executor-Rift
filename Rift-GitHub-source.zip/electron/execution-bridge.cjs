const http = require('node:http');
const {randomBytes, randomUUID, timingSafeEqual} = require('node:crypto');

function createExecutionBridge({host='127.0.0.1',port=0,jobTimeoutMs=30000}={}) {
 let server=null, token=null, address=null, session=null;
 const pending=new Map();
 const safe=(value,max)=>typeof value==='string'&&value.length>0&&value.length<=max;
 function clientInfo(value){
  if(value===undefined)return null;
  if(!value||typeof value!=='object'||Array.isArray(value)||!safe(value.kind,80))throw Error('Invalid runtime client details.');
  for(const key of ['placeId','universeId'])if(value[key]!==undefined&&(!Number.isSafeInteger(value[key])||value[key]<0))throw Error('Invalid runtime client details.');
  if(value.jobId!==undefined&&(typeof value.jobId!=='string'||value.jobId.length>80))throw Error('Invalid runtime client details.');
  return {kind:value.kind,placeId:value.placeId??null,universeId:value.universeId??null,jobId:value.jobId||null};
 }
 const snapshot=()=>({running:!!server,address,connected:!!session&&Date.now()-session.lastSeen<15000,session:session&&{id:session.id,name:session.name,account:session.account,client:session.client,lastSeen:session.lastSeen},pending:pending.size});
 function rejectPending(message){for(const job of pending.values()){clearTimeout(job.timer);job.reject(Error(message))}pending.clear()}
 function respond(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body))}
 async function readBody(req){let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>1_100_000)throw Error('Request body is too large.');chunks.push(chunk)}return JSON.parse(Buffer.concat(chunks).toString('utf8'))}
 function authenticated(req){const supplied=req.headers.authorization?.replace(/^Bearer /,'')||'';const a=Buffer.from(supplied),b=Buffer.from(token||'');return a.length===b.length&&timingSafeEqual(a,b)}
 async function route(req,res){
  if(req.headers.origin){respond(res,403,{error:'Browser origins are not accepted.'});return}
  if(!authenticated(req)){respond(res,401,{error:'Invalid pairing token.'});return}
  const pathname=new URL(req.url,'http://localhost').pathname;
  try{
   if(req.method==='POST'&&pathname==='/v1/session'){
    const body=await readBody(req);
    if(!safe(body.name,80)||!safe(body.account,80))throw Error('A runtime name and account label are required.');
    const client=clientInfo(body.client);
    rejectPending('Runtime session changed.');
    session={id:randomUUID(),name:body.name,account:body.account,client,lastSeen:Date.now()};
    respond(res,200,{sessionId:session.id});return;
   }
   if(!session){respond(res,409,{error:'Register a runtime session first.'});return}
   const id=req.headers['x-rift-session'];
   if(id!==session.id){respond(res,403,{error:'Invalid runtime session.'});return}
   session.lastSeen=Date.now();
   if(req.method==='GET'&&pathname==='/v1/jobs'){
    const job=[...pending.values()].find(item=>!item.delivered);
    if(job){job.delivered=true;respond(res,200,{job:{id:job.id,name:job.name,code:job.code,account:job.account}})}
    else respond(res,200,{job:null});
    return;
   }
   if(req.method==='POST'&&pathname==='/v1/result'){
    const body=await readBody(req),job=pending.get(body.id);
    if(!job){respond(res,404,{error:'Unknown or expired job.'});return}
    if(typeof body.ok!=='boolean'||!Array.isArray(body.output)||body.output.length>1000||body.output.some(line=>typeof line!=='string'||line.length>10000))throw Error('Invalid result.');
    clearTimeout(job.timer);pending.delete(job.id);job.resolve({ok:body.ok,output:body.output,account:session.account});
    respond(res,200,{accepted:true});return;
   }
   respond(res,404,{error:'Unknown endpoint.'});
  }catch(error){respond(res,400,{error:error.message})}
 }
 return {
  status:snapshot,
  async start(){if(server)return {...snapshot(),token};token=randomBytes(32).toString('hex');server=http.createServer((req,res)=>{route(req,res).catch(()=>respond(res,500,{error:'Bridge request failed.'}))});try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve)});address=`http://${host}:${server.address().port}`;return {...snapshot(),token}}catch(error){server=null;token=null;throw error}},
  async stop(){rejectPending('Bridge stopped.');session=null;token=null;address=null;const active=server;server=null;if(active)await new Promise(resolve=>active.close(resolve));return snapshot()},
  execute({name,code,account}){if(!snapshot().connected)throw Error('Connect a runtime before executing.');if(!safe(name,100)||typeof code!=='string'||code.length>1_000_000||!safe(account,80))throw Error('Invalid execution request.');if(account!==session.account)throw Error('Selected account does not match the connected runtime.');if(pending.size>=10)throw Error('Execution queue is full.');const id=randomUUID();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error('Runtime did not return a result in time.'))},jobTimeoutMs);pending.set(id,{id,name,code,account,delivered:false,timer,resolve,reject})})}
 };
}
module.exports={createExecutionBridge};
